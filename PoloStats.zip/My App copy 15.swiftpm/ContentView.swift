import SwiftUI

struct Player: Identifiable, Codable {
    var id = UUID()
    var name: String
    var goals: Int = 0
    var assists: Int = 0
    var steals: Int = 0
    var saves: Int = 0
}

struct ContentView: View {
    @State private var players: [Player] = []
    @State private var showingAddScreen = false
    @State private var selectedStat = "Goals"
    
    let stats = ["Goals", "Assists", "Steals", "Saves"]
    let coldGreen = Color(red: 0.0, green: 0.9, blue: 0.5)
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(white: 0.02).ignoresSafeArea()
                
                VStack(spacing: 0) {
                    VStack(spacing: 4) {
                        Text("POLOSTATS")
                            .font(.system(size: 36, weight: .black, design: .monospaced))
                            .foregroundColor(coldGreen)
                        Text("TEAM LEADERBOARD")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.gray)
                            .tracking(5)
                    }
                    .padding(.top, 25)
                    
                    Picker("Stat", selection: $selectedStat) {
                        ForEach(stats, id: \.self) { Text($0) }
                    }
                    .pickerStyle(.segmented)
                    .padding()
                    .colorMultiply(coldGreen)
                    
                    ScrollView {
                        VStack(spacing: 12) {
                            if players.isEmpty {
                                Text("NO GAME DATA RECORDED")
                                    .font(.system(.caption, design: .monospaced))
                                    .foregroundColor(.gray)
                                    .padding(.top, 60)
                            } else {
                                ForEach(Array(sortedPlayers().enumerated()), id: \.element.id) { index, player in
                                    LeaderboardRow(rank: index + 1, player: player, statLabel: selectedStat, statValue: getVal(for: player), theme: coldGreen)
                                }
                            }
                        }
                        .padding()
                    }
                    
                    Button(action: { showingAddScreen = true }) {
                        HStack {
                            Image(systemName: "plus.app.fill")
                            Text("NEW GAME ENTRY").fontWeight(.black)
                        }
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(coldGreen)
                        .foregroundColor(.black)
                        .cornerRadius(15)
                    }
                    .padding(20)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showingAddScreen) {
                AddStatsView(players: $players, theme: coldGreen)
            }
        }
    }
    
    func sortedPlayers() -> [Player] {
        players.sorted { getVal(for: $0) > getVal(for: $1) }
    }
    
    func getVal(for p: Player) -> Int {
        switch selectedStat {
        case "Goals": return p.goals
        case "Assists": return p.assists
        case "Steals": return p.steals
        case "Saves": return p.saves
        default: return 0
        }
    }
}

struct LeaderboardRow: View {
    let rank: Int
    let player: Player
    let statLabel: String
    let statValue: Int
    let theme: Color
    
    var body: some View {
        HStack(spacing: 15) {
            Text("\(rank)")
                .font(.system(.title3, design: .monospaced))
                .fontWeight(.black)
                .foregroundColor(rank == 1 ? .yellow : .gray)
                .frame(width: 35)
            
            Text(player.name.uppercased())
                .font(.system(.headline, design: .monospaced))
                .foregroundColor(.white)
            
            Spacer()
            
            VStack(alignment: .trailing) {
                Text("\(statValue)")
                    .font(.system(size: 24, weight: .black, design: .monospaced))
                    .foregroundColor(theme)
                Text(statLabel.uppercased())
                    .font(.system(size: 8))
                    .foregroundColor(.gray)
            }
        }
        .padding()
        .background(Color(white: 0.1))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(rank == 1 ? Color.yellow.opacity(0.4) : Color.clear, lineWidth: 1)
        )
    }
}

struct AddStatsView: View {
    @Binding var players: [Player]
    let theme: Color
    
    @State private var name = ""
    @State private var g = ""; @State private var a = ""
    @State private var st = ""; @State private var sv = ""
    
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(white: 0.08).ignoresSafeArea()
                Form {
                    Section(header: Text("PLAYER NAME").foregroundColor(.gray)) {
                        TextField("Name", text: $name)
                    }
                    
                    Section(header: Text("GAME PERFORMANCE").foregroundColor(.gray)) {
                        StatInput(label: "Goals", value: $g)
                        StatInput(label: "Assists", value: $a)
                        StatInput(label: "Steals", value: $st)
                        StatInput(label: "Saves", value: $sv)
                    }
                    
                    Button("COMMIT STATS") {
                        save()
                    }
                    .frame(maxWidth: .infinity)
                    .font(.headline)
                    .foregroundColor(theme)
                    .padding(.vertical, 10)
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("GAME DATA")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
    
    func save() {
        if let i = players.firstIndex(where: { $0.name.lowercased() == name.lowercased() }) {
            players[i].goals += Int(g) ?? 0
            players[i].assists += Int(a) ?? 0
            players[i].steals += Int(st) ?? 0
            players[i].saves += Int(sv) ?? 0
        } else if !name.isEmpty {
            players.append(Player(name: name, goals: Int(g) ?? 0, assists: Int(a) ?? 0, steals: Int(st) ?? 0, saves: Int(sv) ?? 0))
        }
        dismiss()
    }
}

struct StatInput: View {
    let label: String
    @Binding var value: String
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            TextField("0", text: $value)
                .multilineTextAlignment(.trailing)
        }
    }
}
